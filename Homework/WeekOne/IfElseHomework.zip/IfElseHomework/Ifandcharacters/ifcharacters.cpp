#include <iostream>
#include <string> 
using namespace std;

//Yes because the capital of a letter is before the lowercase and that is what it showed.
// It said early computers only had uppercase letters and this is a remnant of that. Also because of the value of the uppercase letter vs the lowercase.

int main()
{
	char letter1;
	char letter2;

	cout << "Please enter two letters:" << endl;
	cout << "Letter One: ";
	cin >> letter1;
	cout << endl;

	cout << "Letter two: ";
	cin >> letter2;
	cout << endl;


	if (letter1 < letter2) {

		cout << "Letter one comes first";

	}
	else {
	
		cout << "Letter two comes first";
	
	}


	while (true) {}
	return 0;
}