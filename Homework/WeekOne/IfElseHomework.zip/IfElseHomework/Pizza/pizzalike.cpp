#include <iostream>
#include <string> 
using namespace std;

// The number 1 is displayed if true and 0 is displayed for false.

int main()
{
	bool likesPizza = false;

	if (likesPizza == true) {
	
		cout << "Likes pizza" << endl;

	}

	else {
	
		cout << "Doesn't like pizza" << endl;

	}


	while (true) {}
	return 0;
}