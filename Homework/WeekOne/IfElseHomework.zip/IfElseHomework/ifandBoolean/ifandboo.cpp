#include <iostream>
#include <string> 
using namespace std;

//Yes you can, anything that makes the expression true will work.

int main()
{
	bool istallenough;
	int feet;

	cout << "How tall are you? " << endl;
	cin >> feet;

	istallenough = feet > 3;

	if (istallenough == true) {
	
		cout << "Can ride the roller coaster" << endl;
	
	}
	else {
	
		cout << "Too short";
	
	}

	while (true) {}
	return 0;
}