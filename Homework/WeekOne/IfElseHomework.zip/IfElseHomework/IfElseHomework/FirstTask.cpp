#include <iostream>
#include <string> 
using namespace std;

// The scope of age is any number at the moment, it is not limited. The if else statement makes it so that if age is under 13 the price will be 5 and if above 13 it will be 7.00

//The two options the price can be is 5.00 dollars and 7.00 dollars

int main()
{
	int age;
	float price;

	cout << "What is your age? ";
	cin >> age;

	if (age < 13) {

		price = 5.00;
	
	}
	else { 
	
		price = 7.00;
	
	}

	cout << "Price for a ticket: " << price << endl;



	while (true) {}
	return 0;
}